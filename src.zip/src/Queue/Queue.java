package Queue;

public class Queue {

    private int[] queue;
    private int front;
    private int rear;
    private int maxSize;

    public Queue(int size) {
        maxSize = size;
        queue = new int[maxSize];
        front = -1;
        rear = -1;
    }

    public boolean isEmpty() {
        return front == -1;
    }

    public boolean isFull() {
        return rear == maxSize - 1;
    }

    public void enQueue(int item) {
        if (isFull()) {
            System.out.println("Queue is full.");
            return;
        }
        if (isEmpty()) {
            front = 0;
        }
        queue[++rear] = item;
    }

    public int deQueue() {
        if (isEmpty()) {
            System.out.println("Queue is empty.");
            return -1;
        }
        int item = queue[front];
        if (front == rear) {
            front = -1;
            rear = -1;
        } else {
            front++;
        }
        return item;
    }

    public int front() {
        if (isEmpty()) {
            System.out.println("Queue is empty.");
            return -1;
        }
        return queue[front];
    }

    public void displayAllElements() {
        if (isEmpty()) {
            System.out.println("Queue is empty.");
            return;
        }
        for (int i = front; i <= rear; i++) {
            System.out.print(queue[i] + " ");
        }
        System.out.println();
    }

    public int maxSize() {
        return maxSize;
    }

    public int minValue() {
        if (isEmpty()) {
            System.out.println("Queue is empty.");
            return -1;
        }
        int min = queue[front];
        for (int i = front; i <= rear; i++) {
            if (queue[i] < min)
                min = queue[i];
        }
        return min;
    }

    public int maxValue() {
        if (isEmpty()) {
            System.out.println("Queue is empty.");
            return -1;
        }
        int max = queue[front];
        for (int i = front; i <= rear; i++) {
            if (queue[i] > max)
                max = queue[i];
        }
        return max;
    }

    public int total() {
        if (isEmpty()) {
            System.out.println("Queue is empty.");
            return 0;
        }
        int sum = 0;
        for (int i = front; i <= rear; i++) {
            sum += queue[i];
        }
        return sum;
    }

    public double average() {
        if (isEmpty()) {
            System.out.println("Queue is empty.");
            return 0;
        }
        return (double) total() / size();
    }

    public boolean search(int key) {
        if (isEmpty()) {
            System.out.println("Queue is empty.");
            return false;
        }
        for (int i = front; i <= rear; i++) {
            if (queue[i] == key)
                return true;
        }
        return false;
    }

    public void addFirst(int item) {
        if (isFull()) {
            System.out.println("Queue is full.");
            return;
        }
        if (isEmpty()) {
            front = 0;
            rear = 0;
        } else {
            for (int i = rear; i >= front; i--) {
                queue[i + 1] = queue[i];
            }
            rear++;
        }
        queue[front] = item;
    }

    public void addLast(int item) {
        enQueue(item);
    }

    public int getFirst() {
        return front();
    }

    public int getFirstElement() {
        if (isEmpty()) {
            System.out.println("Queue is empty.");
            return -1;
        }
        return queue[front];
    }

    public int getLast() {
        if (isEmpty()) {
            System.out.println("Queue is empty.");
            return -1;
        }
        return queue[rear];
    }

    public int getLastElement() {
        if (isEmpty()) {
            System.out.println("Queue is empty.");
            return -1;
        }
        return queue[rear];
    }

    public void removeFirst() {
        deQueue();
    }

    public void removeFirstElement() {
        if (isEmpty()) {
            System.out.println("Queue is empty.");
            return;
        }
        if (front == rear) {
            front = -1;
            rear = -1;
        } else {
            front++;
        }
    }

    public void removeLast() {
        if (isEmpty()) {
            System.out.println("Queue is empty.");
            return;
        }
        if (front == rear) {
            front = -1;
            rear = -1;
        } else {
            rear--;
        }
    }

    public void removeLastElement() {
        removeLast();
    }

    public void removeElement(int key) {
        if (isEmpty()) {
            System.out.println("Queue is empty.");
            return;
        }
        int foundIndex = -1;
        for (int i = front; i <= rear; i++) {
            if (queue[i] == key) {
                foundIndex = i;
                break;
            }
        }
        if (foundIndex == -1) {
            System.out.println("Element not found in the queue.");
            return;
        }
        for (int i = foundIndex; i < rear; i++) {
            queue[i] = queue[i + 1];
        }
        rear--;
    }

    public boolean find(int key) {
        return search(key);
    }

    public void addElement(int item) {
        enQueue(item);
    }

    public int size() {
        if (isEmpty())
            return 0;
        return rear - front + 1;
    }

    public static void main(String[] args) {
        Queue queue = new Queue(5);
        queue.enQueue(10);
        queue.enQueue(20);
        queue.enQueue(30);
        queue.enQueue(40);
        
        queue.displayAllElements();
        queue.deQueue();
        queue.displayAllElements();
        System.out.println("Front element: " + queue.front());
        System.out.println("Is queue empty? " + queue.isEmpty());
        System.out.println("Is queue full? " + queue.isFull());
        System.out.println("Maximum size of the queue: " + queue.maxSize());
        System.out.println("Minimum value in the queue: " + queue.minValue());
        System.out.println("Maximum value in the queue: " + queue.maxValue());
        System.out.println("Total of all elements in the queue: " + queue.total());
        System.out.println("Average of all elements in the queue: " + queue.average());
        System.out.println("Is 20 present in the queue? " + queue.search(20));
        queue.addFirst(5);
        queue.addLast(50);
        queue.displayAllElements();
        queue.removeFirst();
        queue.removeLast();
        queue.displayAllElements();
        queue.removeElement(20);
        queue.displayAllElements();
        System.out.println("Is 20 present in the queue now? " + queue.find(20));
    }
}
