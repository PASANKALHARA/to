package Queue;
public class CircularQueue {

    private int[] queue;
    private int front;
    private int rear;
    private int maxSize;

    public CircularQueue(int size) {
        maxSize = size;
        queue = new int[maxSize];
        front = -1;
        rear = -1;
    }

    public boolean isEmpty() {
        return front == -1;
    }

    public boolean isFull() {
        return (front == 0 && rear == maxSize - 1) || (rear == (front - 1) % (maxSize - 1));
    }

    public void enQueue(int item) {
        if (isFull()) {
            System.out.println("Queue is full.");
            return;
        }

        if (isEmpty()) {
            front = 0;
            rear = 0;
        } else {
            rear = (rear + 1) % maxSize;
        }

        queue[rear] = item;
    }

    public int deQueue() {
        int item;
        if (isEmpty()) {
            System.out.println("Queue is empty.");
            return -1;
        } else if (front == rear) {
            item = queue[front];
            front = -1;
            rear = -1;
        } else {
            item = queue[front];
            front = (front + 1) % maxSize;
        }
        return item;
    }

    public int front() {
        if (isEmpty()) {
            System.out.println("Queue is empty.");
            return -1;
        }
        return queue[front];
    }

    public void displayAllElements() {
        if (isEmpty()) {
            System.out.println("Queue is empty.");
            return;
        }

        int i = front;
        do {
            System.out.print(queue[i] + " ");
            i = (i + 1) % maxSize;
        } while (i != (rear + 1) % maxSize);
        System.out.println();
    }

    public int maxSize() {
        return maxSize;
    }

    public int minValue() {
        if (isEmpty()) {
            System.out.println("Queue is empty.");
            return -1;
        }
        int min = queue[front];
        for (int i = front; i != rear; i = (i + 1) % maxSize) {
            if (queue[i] < min)
                min = queue[i];
        }
        return min;
    }

    public int maxValue() {
        if (isEmpty()) {
            System.out.println("Queue is empty.");
            return -1;
        }
        int max = queue[front];
        for (int i = front; i != rear; i = (i + 1) % maxSize) {
            if (queue[i] > max)
                max = queue[i];
        }
        return max;
    }

    public int total() {
        if (isEmpty()) {
            System.out.println("Queue is empty.");
            return 0;
        }
        int sum = 0;
        int i = front;
        do {
            sum += queue[i];
            i = (i + 1) % maxSize;
        } while (i != (rear + 1) % maxSize);
        return sum;
    }

    public double average() {
        if (isEmpty()) {
            System.out.println("Queue is empty.");
            return 0;
        }
        return (double) total() / size();
    }

    public boolean search(int key) {
        if (isEmpty()) {
            System.out.println("Queue is empty.");
            return false;
        }

        int i = front;
        do {
            if (queue[i] == key)
                return true;
            i = (i + 1) % maxSize;
        } while (i != (rear + 1) % maxSize);

        return false;
    }

    public void addFirst(int item) {
        if ((rear + 1) % maxSize == front) {
            System.out.println("Queue is full.");
            return;
        }

        if (isEmpty()) {
            front = 0;
            rear = 0;
        } else {
            front = (front - 1 + maxSize) % maxSize;
        }

        queue[front] = item;
    }

    public void addLast(int item) {
        enQueue(item);
    }

    public int getFirst() {
        return front();
    }

    public int getFirstElement() {
        return queue[front];
    }

    public int getLast() {
        if (isEmpty()) {
            System.out.println("Queue is empty.");
            return -1;
        }
        return queue[rear];
    }

    public int getLastElement() {
        return queue[rear];
    }

    public void removeFirst() {
        deQueue();
    }

    public void removeFirstElement() {
        if (isEmpty()) {
            System.out.println("Queue is empty.");
            return;
        }
        if (front == rear) {
            front = -1;
            rear = -1;
        } else {
            front = (front + 1) % maxSize;
        }
    }

    public void removeLast() {
        if (isEmpty()) {
            System.out.println("Queue is empty.");
            return;
        }
        if (front == rear) {
            front = -1;
            rear = -1;
        } else {
            rear = (rear - 1 + maxSize) % maxSize;
        }
    }

    public void removeLastElement() {
        removeLast();
    }

    public void removeElement(int key) {
        if (isEmpty()) {
            System.out.println("Queue is empty.");
            return;
        }

        int index = -1;
        int i = front;
        do {
            if (queue[i] == key) {
                index = i;
                break;
            }
            i = (i + 1) % maxSize;
        } while (i != (rear + 1) % maxSize);

        if (index == -1) {
            System.out.println("Element not found.");
            return;
        }

        while (index != rear) {
            queue[index] = queue[(index + 1) % maxSize];
            index = (index + 1) % maxSize;
        }

        rear = (rear - 1 + maxSize) % maxSize;
    }

    public boolean find(int key) {
        return search(key);
    }

    public void addElement(int item) {
        enQueue(item);
    }

    public int size() {
        if (isEmpty())
            return 0;
        return (rear - front + maxSize) % maxSize + 1;
    }

    public static void main(String[] args) {
        CircularQueue queue = new CircularQueue(5);
        queue.enQueue(10);
        queue.enQueue(20);
        queue.enQueue(30);
        queue.enQueue(40);
        queue.displayAllElements();
        queue.deQueue();
        queue.displayAllElements();
        System.out.println("Front element: " + queue.front());
        System.out.println("Is queue empty? " + queue.isEmpty());
        System.out.println("Is queue full? " + queue.isFull());
        System.out.println("Maximum size of the queue: " + queue.maxSize());
        System.out.println("Minimum value in the queue: " + queue.minValue());
        System.out.println("Maximum value in the queue: " + queue.maxValue());
        System.out.println("Total of all elements in the queue: " + queue.total());
        System.out.println("Average of all elements in the queue: " + queue.average());
        System.out.println("Is 20 present in the queue? " + queue.search(20));
        queue.addFirst(5);
        queue.addLast(50);
        queue.displayAllElements();
        queue.removeFirst();
        queue.removeLast();
        queue.displayAllElements();
        queue.removeElement(20);
        queue.displayAllElements();

        System.out.println("Is 20 present in the queue now? " + queue.find(20));
    }
}
