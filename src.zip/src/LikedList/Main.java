package LikedList;

public class Main {
	public static void main(String[] args) {
        LinkedList2 linkedList = new LinkedList2(10);
        linkedList.insert(1);
        linkedList.insert(2);
        linkedList.insert(3);
        linkedList.insert(4);
        linkedList.insert(5);

        System.out.println("Elements in the LinkedList:");
        linkedList.displayAllElements();

        System.out.println("Is LinkedList empty? " + linkedList.isEmpty());
        System.out.println("Is LinkedList full? " + linkedList.isFull());

        System.out.println("Maximum value: " + linkedList.maxValue());
        System.out.println("Minimum value: " + linkedList.minValue());
        System.out.println("Total: " + linkedList.total());
        System.out.println("Average: " + linkedList.average());

        System.out.println("Search for 3: " + linkedList.search(3));
        System.out.println("Search for 6: " + linkedList.search(6));

        linkedList.addFirst(0);
        System.out.println("After adding 0 at first position:");
        linkedList.displayAllElements();

        linkedList.addLast(6);
        System.out.println("After adding 6 at last position:");
        linkedList.displayAllElements();

        System.out.println("First element: " + linkedList.getFirst());
        System.out.println("First element (alias method): " + linkedList.getFirstElement());
        System.out.println("Last element: " + linkedList.getLast());
        System.out.println("Last element (alias method): " + linkedList.getLastElement());

        linkedList.removeFirst();
        System.out.println("After removing first element:");
        linkedList.displayAllElements();

        linkedList.removeLast();
        System.out.println("After removing last element:");
        linkedList.displayAllElements();

        linkedList.removeElement(3);
        System.out.println("After removing element 3:");
        linkedList.displayAllElements();
    }
	
}
