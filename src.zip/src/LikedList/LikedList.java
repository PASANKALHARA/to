package LikedList;

public class LikedList {
    private static final int MAX_SIZE = 100; 
    private Node head; 
    private int size; 

   
    private static class Node {
        int data;
        Node next;

        Node(int data) {
            this.data = data;
            this.next = null;
        }
    }

    
    public LikedList() {
        this.head = null;
        this.size = 0;
    }

    public boolean isEmpty() {
        return size == 0;
    }
    public boolean isFull() {
        return size == MAX_SIZE;
    }

    public void enQueue(int data) {
        if (isFull()) {
            System.out.println("Linked list is full, cannot add more elements.");
            return;
        }
        Node newNode = new Node(data);
        if (isEmpty()) {
            head = newNode;
        } else {
            Node current = head;
            while (current.next != null) {
                current = current.next;
            }
            current.next = newNode;
        }
        size++;
    }
    public void deQueue() {
        if (isEmpty()) {
            System.out.println("Linked list is empty, nothing to remove.");
            return;
        }
        head = head.next;
        size--;
    }

    public int front() {
        if (isEmpty()) {
            System.out.println("Linked list is empty.");
            return -1;
        }
        return head.data;
    }
    public void displayAllElements() {
        if (isEmpty()) {
            System.out.println("Linked list is empty.");
            return;
        }
        Node current = head;
        while (current != null) {
            System.out.print(current.data + " ");
            current = current.next;
        }
        System.out.println();
    }

    public int maxSize() {
        return MAX_SIZE;
    }
    public int minValue() {
        if (isEmpty()) {
            System.out.println("Linked list is empty.");
            return -1;
        }
        int min = head.data;
        Node current = head.next;
        while (current != null) {
            if (current.data < min) {
                min = current.data;
            }
            current = current.next;
        }
        return min;
    }
    public int maxValue() {
        if (isEmpty()) {
            System.out.println("Linked list is empty.");
            return -1;
        }
        int max = head.data;
        Node current = head.next;
        while (current != null) {
            if (current.data > max) {
                max = current.data;
            }
            current = current.next;
        }
        return max;
    }
    public int total() {
        if (isEmpty()) {
            return 0;
        }
        int sum = 0;
        Node current = head;
        while (current != null) {
            sum += current.data;
            current = current.next;
        }
        return sum;
    }
    public double average() {
        if (isEmpty()) {
            return 0;
        }
        return (double) total() / size;
    }
    public boolean search(int key) {
        Node current = head;
        while (current != null) {
            if (current.data == key) {
                return true;
            }
            current = current.next;
        }
        return false;
    }
    public void addFirst(int data) {
        if (isFull()) {
            System.out.println("Linked list is full, cannot add more elements.");
            return;
        }
        Node newNode = new Node(data);
        newNode.next = head;
        head = newNode;
        size++;
    }

    public void addLast(int data) {
        enQueue(data);
    }

    public int getFirst() {
        return front();
    }
    public int getFirstElement() {
        return front();
    }
    public int getLast() {
        if (isEmpty()) {
            System.out.println("Linked list is empty.");
            return -1;
        }
        Node current = head;
        while (current.next != null) {
            current = current.next;
        }
        return current.data;
    }
    public int getLastElement() {
        return getLast();
    }
    public void removeFirst() {
        deQueue();
    }
    public void removeFirstElement(int key) {
        if (isEmpty()) {
            System.out.println("Linked list is empty, nothing to remove.");
            return;
        }
        if (head.data == key) {
            head = head.next;
            size--;
            return;
        }
        Node prev = head;
        Node current = head.next;
        while (current != null) {
            if (current.data == key) {
                prev.next = current.next;
                size--;
                return;
            }
            prev = current;
            current = current.next;
        }
        System.out.println("Element " + key + " not found in the linked list.");
    }

    // Method to remove the last element from the linked list
    public void removeLast() {
        if (isEmpty()) {
            System.out.println("Linked list is empty, nothing to remove.");
            return;
        }
        if (head.next == null) {
            head = null;
            size--;
            return;
        }
        Node prev = null;
        Node current = head;
        while (current.next != null) {
            prev = current;
            current = current.next;
        }
        prev.next = null;
        size--;
    }

    // Method to remove the last occurrence of a specified element from the linked list
    public void removeLastElement(int key) {
        if (isEmpty()) {
            System.out.println("Linked list is empty, nothing to remove.");
            return;
        }
        if (head.data == key) {
            head = head.next;
            size--;
            return;
        }
        Node prev = null;
        Node current = head;
        Node lastOccurrence = null;
        while (current != null) {
            if (current.data == key) {
                lastOccurrence = prev;
            }
            prev = current;
            current = current.next;
        }
        if (lastOccurrence != null) {
            lastOccurrence.next = lastOccurrence.next.next;
            size--;
        } else {
            System.out.println("Element " + key + " not found in the linked list.");
        }
    }

    // Method to remove all occurrences of a specified element from the linked list
    public void removeElement(int key) {
        if (isEmpty()) {
            System.out.println("Linked list is empty, nothing to remove.");
            return;
        }
        while (head != null && head.data == key) {
            head = head.next;
            size--;
        }
        Node prev = null;
        Node current = head;
        while (current != null) {
            if (current.data == key) {
                prev.next = current.next;
                size--;
            } else {
                prev = current;
            }
            current = current.next;
        }
    }
    public int find(int key) {
        if (isEmpty()) {
            return -1;
        }
        int index = 0;
        Node current = head;
        while (current != null) {
            if (current.data == key) {
                return index;
            }
            current = current.next;
            index++;
        }
        return -1;
    }
    public void addElement(int index, int data) {
        if (index < 0 || index > size) {
            System.out.println("Invalid index.");
            return;
        }
        if (isFull()) {
            System.out.println("Linked list is full, cannot add more elements.");
            return;
        }
        if (index == 0) {
            addFirst(data);
            return;
        }
        if (index == size) {
            addLast(data);
            return;
        }
        Node newNode = new Node(data);
        Node current = head;
        for (int i = 0; i < index - 1; i++) {
            current = current.next;
        }
        newNode.next = current.next;
        current.next = newNode;
        size++;
    }

    public static void main(String[] args) {
        LikedList linkedList = new LikedList();
        linkedList.enQueue(10);
        linkedList.enQueue(20);
        linkedList.enQueue(30);
        linkedList.displayAllElements();
        System.out.println("First element: " + linkedList.getFirst());
        System.out.println("Last element: " + linkedList.getLast());
        System.out.println("Total elements: " + linkedList.size);
    }
}
