package LikedList;
public class LinkedList2 {
    private Node head;
    private int size;
    private int maxSize;

    
    public LinkedList2(int maxSize) {
        this.head = null;
        this.size = 0;
        this.maxSize = maxSize;
    }
    
    

    public void insert(int data) {
        if (size >= maxSize) {
            System.out.println("LinkedList is full. Cannot insert more elements.");
            return;
        }
        Node newNode = new Node(data);
        if (head == null) {
            head = newNode;
        } else {
            Node temp = head;
            while (temp.next != null) {
                temp = temp.next;
            }
            temp.next = newNode;
        }
        size++;
    }

    public void remove(int data) {
        if (head == null) {
            System.out.println("LinkedList is empty. Cannot remove element.");
            return;
        }
        if (head.data == data) {
            head = head.next;
            size--;
            return;
        }
        Node prev = null;
        Node curr = head;
        while (curr != null && curr.data != data) {
            prev = curr;
            curr = curr.next;
        }
        if (curr == null) {
            System.out.println("Element not found.");
            return;
        }
        prev.next = curr.next;
        size--;
    }

    public boolean isEmpty() {
        return size == 0;
    }

    public boolean isFull() {
        return size == maxSize;
    }

    public void displayAllElements() {
        if (head == null) {
            System.out.println("LinkedList is empty.");
            return;
        }
        Node temp = head;
        while (temp != null) {
            System.out.print(temp.data + " ");
            temp = temp.next;
        }
        System.out.println();
    }

    public int maxSize() {
        return maxSize;
    }

    public int minValue() {
        if (head == null) {
            System.out.println("LinkedList is empty.");
            return Integer.MIN_VALUE;
        }
        Node temp = head;
        int min = Integer.MAX_VALUE;
        while (temp != null) {
            if (temp.data < min)
                min = temp.data;
            temp = temp.next;
        }
        return min;
    }

    public int maxValue() {
        if (head == null) {
            System.out.println("LinkedList is empty.");
            return Integer.MAX_VALUE;
        }
        Node temp = head;
        int max = Integer.MIN_VALUE;
        while (temp != null) {
            if (temp.data > max)
                max = temp.data;
            temp = temp.next;
        }
        return max;
    }

    public int total() {
        if (head == null) {
            System.out.println("LinkedList is empty.");
            return 0;
        }
        Node temp = head;
        int sum = 0;
        while (temp != null) {
            sum += temp.data;
            temp = temp.next;
        }
        return sum;
    }

    public double average() {
        if (isEmpty()) {
            System.out.println("LinkedList is empty.");
            return 0.0;
        }
        return (double) total() / size;
    }

    public boolean search(int key) {
        Node temp = head;
        while (temp != null) {
            if (temp.data == key)
                return true;
            temp = temp.next;
        }
        return false;
    }

    public void addFirst(int data) {
        if (size >= maxSize) {
            System.out.println("LinkedList is full. Cannot add more elements.");
            return;
        }
        Node newNode = new Node(data);
        newNode.next = head;
        head = newNode;
        size++;
    }

    public void addLast(int data) {
        if (size >= maxSize) {
            System.out.println("LinkedList is full. Cannot add more elements.");
            return;
        }
        Node newNode = new Node(data);
        if (head == null) {
            head = newNode;
        } else {
            Node temp = head;
            while (temp.next != null) {
                temp = temp.next;
            }
            temp.next = newNode;
        }
        size++;
    }

    public int getFirst() {
        if (head == null) {
            System.out.println("LinkedList is empty.");
            return Integer.MIN_VALUE;
        }
        return head.data;
    }

    public int getFirstElement() {
        return getFirst();
    }

    public int getLast() {
        if (head == null) {
            System.out.println("LinkedList is empty.");
            return Integer.MIN_VALUE;
        }
        Node temp = head;
        while (temp.next != null) {
            temp = temp.next;
        }
        return temp.data;
    }

    public int getLastElement() {
        return getLast();
    }

    public void removeFirst() {
        if (head == null) {
            System.out.println("LinkedList is empty. Cannot remove first element.");
            return;
        }
        head = head.next;
        size--;
    }

    public void removeFirstElement() {
        removeFirst();
    }

    public void removeLast() {
        if (head == null) {
            System.out.println("LinkedList is empty. Cannot remove last element.");
            return;
        }
        if (head.next == null) {
            head = null;
            size--;
            return;
        }
        Node temp = head;
        while (temp.next.next != null) {
            temp = temp.next;
        }
        temp.next = null;
        size--;
    }

    public void removeLastElement() {
        removeLast();
    }

    public void removeElement(int data) {
        if (head == null) {
            System.out.println("LinkedList is empty. Cannot remove element.");
            return;
        }
        if (head.data == data) {
            head = head.next;
            size--;
            return;
        }
        Node prev = null;
        Node curr = head;
        while (curr != null && curr.data != data) {
            prev = curr;
            curr = curr.next;
        }
        if (curr == null) {
            System.out.println("Element not found.");
            return;
        }
        prev.next = curr.next;
        size--;
    }

    public boolean find(int key) {
        return search(key);
    }

    public void addElement(int data) {
        insert(data);
    }

    
}

