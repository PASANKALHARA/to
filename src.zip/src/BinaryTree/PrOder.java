package BinaryTree;

public class PrOder {

    private Node root;
    private static class Node {
        int data;
        Node left, right;

        Node(int data) {
            this.data = data;
            left = right = null;
        }
    }

    public PrOder() {
        root = null;
    }

    public void PrOderTraversal() {
        PrOderTraversal(root);
    }

    private void PrOderTraversal(Node root) {
        if (root != null) {
            System.out.print(root.data + " ");
            PrOderTraversal(root.left);
            PrOderTraversal(root.right);
        }
    }
    public void displayPrOder() {
        PrOderTraversal();
        System.out.println();
    }
    public void insert(int value) {
        root = insertRecursive(root, value);
    }

    private Node insertRecursive(Node root, int value) {
        if (root == null) {
            root = new Node(value);
            return root;
        }

        if (value < root.data)
            root.left = insertRecursive(root.left, value);
        else if (value > root.data)
            root.right = insertRecursive(root.right, value);

        return root;
    }
    public void displayAllElements() {
        System.out.print("Pre-order traversal: ");
        displayPrOder();
    }

    public static void main(String[] args) {
        PrOder tree = new PrOder();
        tree.insert(50);
        tree.insert(30);
        tree.insert(70);
        tree.insert(20);
        tree.insert(40);
        tree.insert(60);
        tree.insert(80);

        System.out.println("Pre-order traversal:");
        tree.displayAllElements();
    }
}
