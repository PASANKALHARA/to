package BinaryTree;

public class PosOder {

    private Node root;

    // Node class definition
    private static class Node {
        int data;
        Node left, right;

        Node(int data) {
            this.data = data;
            left = right = null;
        }
    }

    // Constructor
    public PosOder() {
        root = null;
    }

    // Method to perform post-order traversal
    public void PosOderTraversal() {
        PosOderTraversal(root);
    }

    private void PosOderTraversal(Node root) {
        if (root != null) {
            PosOderTraversal(root.left);
            PosOderTraversal(root.right);
            System.out.print(root.data + " ");
        }
    }

    // Method to display all elements (post-order)
    public void displayPosOder() {
        PosOderTraversal();
        System.out.println();
    }

    // Method to insert a value into the binary tree
    public void insert(int value) {
        root = insertRecursive(root, value);
    }

    private Node insertRecursive(Node root, int value) {
        if (root == null) {
            root = new Node(value);
            return root;
        }

        if (value < root.data)
            root.left = insertRecursive(root.left, value);
        else if (value > root.data)
            root.right = insertRecursive(root.right, value);

        return root;
    }

    // Method to display all elements in the binary tree
    public void displayAllElements() {
        System.out.print("Post-order traversal: ");
        displayPosOder();
    }

    public static void main(String[] args) {
        PosOder tree = new PosOder();
        tree.insert(50);
        tree.insert(30);
        tree.insert(70);
        tree.insert(20);
        tree.insert(40);
        tree.insert(60);
        tree.insert(80);

        //System.out.println("Post-order traversal:");
        tree.displayAllElements();
    }
}
