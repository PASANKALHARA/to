package BinaryTree;

public class BinaryTree {

    private Node root;

    // Node class definition
    private static class Node {
        int data;
        Node left, right;

        Node(int data) {
            this.data = data;
            left = right = null;
        }
    }

    // Constructor
    public BinaryTree() {
        root = null;
    }

    // Method to insert a value into the binary tree
    public void insert(int value) {
        root = insertRecursive(root, value);
    }

    private Node insertRecursive(Node root, int value) {
        if (root == null) {
            root = new Node(value);
            return root;
        }

        if (value < root.data)
            root.left = insertRecursive(root.left, value);
        else if (value > root.data)
            root.right = insertRecursive(root.right, value);

        return root;
    }

    // Method to remove a value from the binary tree
    public void remove(int value) {
        root = removeRecursive(root, value);
    }

    private Node removeRecursive(Node root, int value) {
        if (root == null) return root;

        if (value < root.data)
            root.left = removeRecursive(root.left, value);
        else if (value > root.data)
            root.right = removeRecursive(root.right, value);
        else {
            if (root.left == null)
                return root.right;
            else if (root.right == null)
                return root.left;

            root.data = minValue(root.right);
            root.right = removeRecursive(root.right, root.data);
        }
        return root;
    }

    // Method to find the minimum value in the binary tree
    public int minValue() {
        return minValue(root);
    }

    private int minValue(Node root) {
        int minv = root.data;
        while (root.left != null) {
            minv = root.left.data;
            root = root.left;
        }
        return minv;
    }

    // Method to display all elements in the binary tree
    public void displayAllElements() {
        displayAllElements(root);
    }

    private void displayAllElements(Node root) {
        if (root != null) {
            displayAllElements(root.left);
            System.out.print(root.data + " ");
            displayAllElements(root.right);
        }
    }

    // Other methods can be implemented similarly

    public static void main(String[] args) {
        BinaryTree tree = new BinaryTree();
        tree.insert(50);
        tree.insert(30);
        tree.insert(20);
        tree.insert(40);
        tree.insert(70);
        tree.insert(60);
        tree.insert(80);

        System.out.println("Inorder traversal:");
        tree.displayAllElements();

        System.out.println("\nMin value: " + tree.minValue());

        tree.remove(20);
        System.out.println("After removing 20:");
        tree.displayAllElements();
    }
}
