package BinaryTree;

public class InOrder {

    private Node root;


    private static class Node {
        int data;
        Node left, right;

        Node(int data) {
            this.data = data;
            left = right = null;
        }
    }

    
    public InOrder() {
        root = null;
    }

    
    public void inOrder() {
        inOrderTraversal(root);
    }

    private void inOrderTraversal(Node root) {
        if (root != null) {
            inOrderTraversal(root.left);
            System.out.print(root.data + " ");
            inOrderTraversal(root.right);
        }
    }

    
    public void displayInOrder() {
        inOrder();
        System.out.println();
    }


    public void insert(int value) {
        root = insertRecursive(root, value);
    }

    private Node insertRecursive(Node root, int value) {
        if (root == null) {
            root = new Node(value);
            return root;
        }

        if (value < root.data)
            root.left = insertRecursive(root.left, value);
        else if (value > root.data)
            root.right = insertRecursive(root.right, value);

        return root;
    }

    public void remove(int value) {
        root = removeRecursive(root, value);
    }

    private Node removeRecursive(Node root, int value) {
        if (root == null) return root;

        if (value < root.data)
            root.left = removeRecursive(root.left, value);
        else if (value > root.data)
            root.right = removeRecursive(root.right, value);
        else {
            if (root.left == null)
                return root.right;
            else if (root.right == null)
                return root.left;

            root.data = minValue(root.right);
            root.right = removeRecursive(root.right, root.data);
        }
        return root;
    }
    public int minValue() {
        return minValue(root);
    }

    private int minValue(Node root) {
        int minv = root.data;
        while (root.left != null) {
            minv = root.left.data;
            root = root.left;
        }
        return minv;
    }
    public void displayAllElements() {
        System.out.print("In-order traversal: ");
        displayInOrder(root);
        System.out.println();
    }

    private void displayInOrder(Node root) {
        if (root != null) {
            displayInOrder(root.left);
            System.out.print(root.data + " ");
            displayInOrder(root.right);
        }
    }

    public static void main(String[] args) {
        InOrder tree = new InOrder();
        tree.insert(50);
        tree.insert(30);
        tree.insert(70);
        tree.insert(20);
        tree.insert(40);
        tree.insert(60);
        tree.insert(80);

        System.out.println("In-order traversal:");
        tree.displayAllElements();

        System.out.println("Min value: " + tree.minValue());

        tree.remove(20);
        System.out.println("After removing 20:");
        tree.displayAllElements();
    }
}
