package Array;

public class ThreeDArray {

    private int[][][] array3;

    public ThreeDArray(int[][][] array) {
        this.array3 = array;
    }

    public void displayAllElements() {
        for (int[][] arr2D : array3) {
            for (int[] arr1D : arr2D) {
                for (int num : arr1D) {
                    System.out.print(num + " ");
                }
                System.out.println();
            }
            System.out.println();
        }
    }

    public void displayElement(int i, int j, int k) {
        if (i >= 0 && i < array3.length && j >= 0 && j < array3[i].length && k >= 0 && k < array3[i][j].length) {
            System.out.println("Element at index [" + i + "][" + j + "][" + k + "]: " + array3[i][j][k]);
        } else {
            System.out.println("Invalid index.");
        }
    }

    public boolean search(int element) {
        for (int[][] arr2D : array3) {
            for (int[] arr1D : arr2D) {
                for (int num : arr1D) {
                    if (num == element) {
                        return true;
                    }
                }
            }
        }
        return false;
    }

    public void addFirst(int[][] newArray2D) {
        int[][][] newArray3 = new int[array3.length + 1][][];
        newArray3[0] = newArray2D;
        System.arraycopy(array3, 0, newArray3, 1, array3.length);
        array3 = newArray3;
    }

    public void addLast(int[][] newArray2D) {
        int[][][] newArray3 = new int[array3.length + 1][][];
        System.arraycopy(array3, 0, newArray3, 0, array3.length);
        newArray3[array3.length] = newArray2D;
        array3 = newArray3;
    }

    public int[][] getFirst() {
        return array3[0];
    }

    public int[][] getLast() {
        return array3[array3.length - 1];
    }

    public void removeFirst() {
        int[][][] newArray3 = new int[array3.length - 1][][];
        System.arraycopy(array3, 1, newArray3, 0, newArray3.length);
        array3 = newArray3;
    }

    public void removeLast() {
        int[][][] newArray3 = new int[array3.length - 1][][];
        System.arraycopy(array3, 0, newArray3, 0, newArray3.length);
        array3 = newArray3;
    }

    public void removeElement(int element) {
        for (int i = 0; i < array3.length; i++) {
            for (int j = 0; j < array3[i].length; j++) {
                for (int k = 0; k < array3[i][j].length; k++) {
                    if (array3[i][j][k] == element) {
                        array3[i][j][k] = 0; // Or any other default value
                    }
                }
            }
        }
    }

    public void addElement(int i, int j, int[] newElementArray) {
        if (i >= 0 && i < array3.length && j >= 0 && j < array3[i].length) {
            array3[i][j] = newElementArray;
        } else {
            System.out.println("Invalid index.");
        }
    }

    public static void main(String[] args) {
        int[][][] Array3 = {
            {{10,20,30,40,50},{40,50,60,78,55,65}},
            {{45,85,65,45,89,45},{45,88,56,45,78,86}}
        };

        ThreeDArray threedArray = new ThreeDArray(Array3);

        // Example usage of added methods
        threedArray.displayAllElements();
        threedArray.displayElement(0, 1, 2);
        System.out.println("Is 78 present? " + threedArray.search(78));

        int[][] new2DArray = {{1, 2, 3}, {4, 5, 6}};
        threedArray.addFirst(new2DArray);

        int[][] another2DArray = {{7, 8, 9}, {10, 11, 12}};
        threedArray.addLast(another2DArray);

        System.out.println("First 2D array:");
        int[][] first2D = threedArray.getFirst();
        for (int[] row : first2D) {
            for (int num : row) {
                System.out.print(num + " ");
            }
            System.out.println();
        }

        System.out.println("Last 2D array:");
        int[][] last2D = threedArray.getLast();
        for (int[] row : last2D) {
            for (int num : row) {
                System.out.print(num + " ");
            }
            System.out.println();
        }

        threedArray.removeFirst();
        threedArray.removeLast();

        threedArray.removeElement(78);

        int[] newElement = {100, 200, 300};
        threedArray.addElement(1, 1, newElement);
    }
}
