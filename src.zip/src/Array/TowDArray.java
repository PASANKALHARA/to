package Array;

public class TowDArray {

	 private int[][] tdArray;

	    public TowDArray(int[][] array) {
	        this.tdArray = array;
	    }

	    // Method to display all elements in the 2D array
	    public void displayAllElements() {
	        for (int[] row : tdArray) {
	            for (int element : row) {
	                System.out.print(element + " ");
	            }
	            System.out.println();
	        }
	    }

	    // Method to display a specific element at given indices
	    public void displayElement(int row, int col) {
	        if (row >= 0 && row < tdArray.length && col >= 0 && col < tdArray[row].length) {
	            System.out.println("Element at row " + row + " and column " + col + " is: " + tdArray[row][col]);
	        } else {
	            System.out.println("Invalid indices!");
	        }
	    }

	    // Method to search for a given element in the 2D array
	    public boolean search(int target) {
	        for (int[] row : tdArray) {
	            for (int element : row) {
	                if (element == target) {
	                    return true;
	                }
	            }
	        }
	        return false;
	    }

	    // Method to add an element at the beginning of the 2D array
	    public void addFirst(int element) {
	        int[][] newArray = new int[tdArray.length + 1][];
	        newArray[0] = new int[]{element};
	        for (int i = 0; i < tdArray.length; i++) {
	            newArray[i + 1] = tdArray[i];
	        }
	        tdArray = newArray;
	    }

	    // Method to add an element at the end of the 2D array
	    public void addLast(int element) {
	        int[][] newArray = new int[tdArray.length + 1][];
	        System.arraycopy(tdArray, 0, newArray, 0, tdArray.length);
	        newArray[tdArray.length] = new int[]{element};
	        tdArray = newArray;
	    }

	    // Method to get the first element of the 2D array
	    public int getFirst() {
	        if (tdArray.length > 0 && tdArray[0].length > 0) {
	            return tdArray[0][0];
	        } else {
	            throw new IllegalStateException("Array is empty!");
	        }
	    }

	    // Method to get the last element of the 2D array
	    public int getLast() {
	        if (tdArray.length > 0 && tdArray[tdArray.length - 1].length > 0) {
	            return tdArray[tdArray.length - 1][tdArray[tdArray.length - 1].length - 1];
	        } else {
	            throw new IllegalStateException("Array is empty!");
	        }
	    }

	    // Method to remove the first row of the 2D array
	    public void removeFirst() {
	        if (tdArray.length > 0) {
	            int[][] newArray = new int[tdArray.length - 1][];
	            System.arraycopy(tdArray, 1, newArray, 0, tdArray.length - 1);
	            tdArray = newArray;
	        } else {
	            throw new IllegalStateException("Array is empty!");
	        }
	    }

	    // Method to remove the last row of the 2D array
	    public void removeLast() {
	        if (tdArray.length > 0) {
	            int[][] newArray = new int[tdArray.length - 1][];
	            System.arraycopy(tdArray, 0, newArray, 0, tdArray.length - 1);
	            tdArray = newArray;
	        } else {
	            throw new IllegalStateException("Array is empty!");
	        }
	    }

	    // Method to remove a specific element from the 2D array
	    public void removeElement(int row, int col) {
	        if (row >= 0 && row < tdArray.length && col >= 0 && col < tdArray[row].length) {
	            int[][] newArray = new int[tdArray.length][];
	            for (int i = 0; i < tdArray.length; i++) {
	                if (i == row) {
	                    newArray[i] = new int[tdArray[i].length - 1];
	                    System.arraycopy(tdArray[i], 0, newArray[i], 0, col);
	                    System.arraycopy(tdArray[i], col + 1, newArray[i], col, tdArray[i].length - col - 1);
	                } else {
	                    newArray[i] = tdArray[i];
	                }
	            }
	            tdArray = newArray;
	        } else {
	            throw new IllegalArgumentException("Invalid indices!");
	        }
	    }

	    // Method to add an element at a specific position in the 2D array
	    public void addElement(int row, int col, int element) {
	        if (row >= 0 && row <= tdArray.length && col >= 0) {
	            int[][] newArray = new int[tdArray.length + 1][];
	            for (int i = 0; i < newArray.length; i++) {
	                if (i == row) {
	                    newArray[i] = new int[tdArray.length > 0 ? tdArray[0].length : 0];
	                    for (int j = 0; j < newArray[i].length; j++) {
	                        if (j == col) {
	                            newArray[i][j] = element;
	                        } else {
	                            newArray[i][j] = 0; // Filling default value for new element
	                        }
	                    }
	                } else if (i < row) {
	                    newArray[i] = tdArray[i];
	                } else {
	                    newArray[i] = tdArray[i - 1];
	                }
	            }
	            tdArray = newArray;
	        } else {
	            throw new IllegalArgumentException("Invalid indices!");
	        }
	    }

	    public static void main(String[] args) {
	        int[][] tdArray = {{1, 2, 3, 4, 5, 6}, {1, 2, 3, 4, 5}};
	        TowDArray array = new TowDArray(tdArray);

	        array.displayAllElements();

	        array.displayElement(0, 2);

	        System.out.println("Is 7 present? " + array.search(7));
	        System.out.println("Is 3 present? " + array.search(3));

	        array.addFirst(0);
	        array.displayAllElements();

	        array.addLast(7);
	        array.displayAllElements();

	        System.out.println("First element: " + array.getFirst());
	        System.out.println("Last element: " + array.getLast());

	        array.removeFirst();
	        array.displayAllElements();

	        array.removeLast();
	        array.displayAllElements();

	        array.removeElement(0, 2);
	        array.displayAllElements();

	        array.addElement(1, 3, 8);
	        array.displayAllElements();
	    }

}
