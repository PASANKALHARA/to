package Array;

public class OneDarray {

	private int[] array;
    private int size;

    public OneDarray(int capacity) {
        array = new int[capacity];
        size = 0;
    }

    public void displayArray() {
        System.out.print("Array Elements: ");
        for (int i = 0; i < size; i++) {
            System.out.print(array[i] + " ");
        }
        System.out.println();
    }

    public void search(int element) {
        for (int i = 0; i < size; i++) {
            if (array[i] == element) {
                System.out.println("Element found at index " + i);
                return;
            }
        }
        System.out.println("Element not found");
    }

    public void addFirst(int element) {
        if (size == array.length) {
            System.out.println("Array is full, cannot add more elements");
            return;
        }
        for (int i = size; i > 0; i--) {
            array[i] = array[i - 1];
        }
        array[0] = element;
        size++;
    }

    public void addLast(int element) {
        if (size == array.length) {
            System.out.println("Array is full, cannot add more elements");
            return;
        }
        array[size] = element;
        size++;
    }

    public int getFirst() {
        if (size == 0) {
            System.out.println("Array is empty");
            return -1; // Return a default value indicating failure
        }
        return array[0];
    }

    public int getLast() {
        if (size == 0) {
            System.out.println("Array is empty");
            return -1; // Return a default value indicating failure
        }
        return array[size - 1];
    }

    public void removeFirst() {
        if (size == 0) {
            System.out.println("Array is empty");
            return;
        }
        for (int i = 0; i < size - 1; i++) {
            array[i] = array[i + 1];
        }
        size--;
    }

    public void removeLast() {
        if (size == 0) {
            System.out.println("Array is empty");
            return;
        }
        size--;
    }

    public void removeElement(int element) {
        int index = -1;
        for (int i = 0; i < size; i++) {
            if (array[i] == element) {
                index = i;
                break;
            }
        }
        if (index == -1) {
            System.out.println("Element not found in the array");
            return;
        }
        for (int i = index; i < size - 1; i++) {
            array[i] = array[i + 1];
        }
        size--;
    }

    public void addElement(int index, int element) {
        if (index < 0 || index > size) {
            System.out.println("Invalid index");
            return;
        }
        if (size == array.length) {
            System.out.println("Array is full, cannot add more elements");
            return;
        }
        for (int i = size; i > index; i--) {
            array[i] = array[i - 1];
        }
        array[index] = element;
        size++;
    }

    public static void main(String[] args) {

    	OneDarray arr = new OneDarray(10);

        arr.addLast(1);
        arr.addLast(2);
        arr.addLast(5);
        arr.addLast(3);
        arr.addLast(6);
        arr.addLast(4);
        arr.addLast(8);
        arr.addLast(9);
        arr.addLast(10);

        arr.displayArray();

        arr.search(5);
        arr.search(7);

        arr.addFirst(0);
        arr.displayArray();

        arr.addLast(11);
        arr.displayArray();

        System.out.println("First element: " + arr.getFirst());
        System.out.println("Last element: " + arr.getLast());

        arr.removeFirst();
        arr.displayArray();

        arr.removeLast();
        arr.displayArray();

        arr.removeElement(5);
        arr.displayArray();

        arr.addElement(3, 7);
        arr.displayArray();
    }

}
