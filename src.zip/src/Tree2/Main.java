package Tree2;
public class Main {
    public static void main(String[] args) {
        ArrayTree tree = new ArrayTree(10);

        tree.insert(5);
        tree.insert(3);
        tree.insert(8);
        tree.insert(1);
        tree.insert(4);
        tree.insert(7);
        tree.insert(9);

        System.out.println("Tree elements:");
        tree.displayAllElements();

        System.out.println("Minimum value: " + tree.minValue());
        System.out.println("Maximum value: " + tree.maxValue());
        System.out.println("Total: " + tree.total());
        System.out.println("Average: " + tree.average());
        System.out.println("Max Size: " + tree.maxSize());

        int elementToSearch = 4;
        System.out.println("Is " + elementToSearch + " present in the tree? " + tree.search(elementToSearch));

        int elementToRemove = 8;
        tree.remove(elementToRemove);
        System.out.println("Tree elements after removing " + elementToRemove + ":");
        tree.displayAllElements();

        tree.delete();
        System.out.println("Tree elements after deletion:");
        tree.displayAllElements();
    }
}
