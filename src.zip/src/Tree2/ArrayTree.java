package Tree2;
public class ArrayTree {
    private int[] treeArray;
    private int size;
    private int maxSize;

    public ArrayTree(int maxSize) {
        this.maxSize = maxSize;
        this.treeArray = new int[maxSize];
        this.size = 0;
    }

    // Insert a new element into the tree
    public void insert(int element) {
        if (size < maxSize) {
            treeArray[size] = element;
            size++;
        } else {
            System.out.println("Tree is full, cannot insert more elements.");
        }
    }

    // Remove an element from the tree
    public void remove(int element) {
        for (int i = 0; i < size; i++) {
            if (treeArray[i] == element) {
                for (int j = i; j < size - 1; j++) {
                    treeArray[j] = treeArray[j + 1];
                }
                size--;
                break;
            }
        }
    }

    // Delete the entire tree
    public void delete() {
        treeArray = new int[maxSize];
        size = 0;
    }

    // Delete a specific element from the tree
    public void deleteElement(int element) {
        remove(element);
    }

    // Display all elements in the tree
    public void displayAllElements() {
        for (int i = 0; i < size; i++) {
            System.out.print(treeArray[i] + " ");
        }
        System.out.println();
    }

    // Display a specific element in the tree
    public void displayElement(int index) {
        if (index >= 0 && index < size) {
            System.out.println(treeArray[index]);
        } else {
            System.out.println("Index out of bounds.");
        }
    }

    // Find the maximum size of the tree
    public int maxSize() {
        return maxSize;
    }

    // Find the minimum value in the tree
    public int minValue() {
        if (size == 0) {
            System.out.println("Tree is empty.");
            return -1;
        }

        int min = treeArray[0];
        for (int i = 1; i < size; i++) {
            if (treeArray[i] < min) {
                min = treeArray[i];
            }
        }
        return min;
    }

    // Find the maximum value in the tree
    public int maxValue() {
        if (size == 0) {
            System.out.println("Tree is empty.");
            return -1;
        }

        int max = treeArray[0];
        for (int i = 1; i < size; i++) {
            if (treeArray[i] > max) {
                max = treeArray[i];
            }
        }
        return max;
    }

    // Calculate the total sum of elements in the tree
    public int total() {
        int sum = 0;
        for (int i = 0; i < size; i++) {
            sum += treeArray[i];
        }
        return sum;
    }
    public double average() {
        if (size == 0) {
            System.out.println("Tree is empty.");
            return 0;
        }
        return (double) total() / size;
    }
    public boolean search(int element) {
        for (int i = 0; i < size; i++) {
            if (treeArray[i] == element) {
                return true;
            }
        }
        return false;
    }
}


