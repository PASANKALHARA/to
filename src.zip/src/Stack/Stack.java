package Stack;

public class Stack {
    private int[] array;
    private int top;
    private int maxSize;

    // Constructor to initialize the stack with a maximum size
    public Stack(int maxSize) {
        this.maxSize = maxSize;
        array = new int[maxSize];
        top = -1; // Initialize top pointer to -1
    }

    // Method to push an element onto the stack
    public void push(int element) {
        if (top == maxSize - 1) {
            System.out.println("Stack Overflow");
            return;
        }
        array[++top] = element;
    }

    // Method to pop an element from the stack
    public int pop() {
        if (isEmpty()) {
            System.out.println("Stack Underflow");
            return -1;
        }
        return array[top--];
    }

    // Method to peek at the top element of the stack without removing it
    public int peek() {
        if (isEmpty()) {
            System.out.println("Stack is empty");
            return -1;
        }
        return array[top];
    }

    // Method to check if the stack is empty
    public boolean isEmpty() {
        return top == -1;
    }

    // Method to display all elements in the stack
    public void displayAllElements() {
        if (isEmpty()) {
            System.out.println("Stack is empty");
            return;
        }
        System.out.print("Stack Elements: ");
        for (int i = top; i >= 0; i--) {
            System.out.print(array[i] + " ");
        }
        System.out.println();
    }

    // Method to display the top element of the stack
    public void displayElement() {
        if (isEmpty()) {
            System.out.println("Stack is empty");
            return;
        }
        System.out.println("Top element of the stack: " + array[top]);
    }

    // Method to get the maximum size of the stack
    public int maxSize() {
        return maxSize;
    }

    // Method to calculate the total sum of all elements in the stack
    public int total() {
        int sum = 0;
        for (int i = 0; i <= top; i++) {
            sum += array[i];
        }
        return sum;
    }

    // Method to calculate the average of all elements in the stack
    public double average() {
        if (isEmpty()) {
            System.out.println("Stack is empty");
            return 0;
        }
        return (double) total() / (top + 1);
    }

    // Method to search for an element in the stack
    public boolean search(int element) {
        for (int i = 0; i <= top; i++) {
            if (array[i] == element) {
                return true;
            }
        }
        return false;
    }

    // Other methods like addFirst, addLast, getFirst, getLast, removeFirst, removeLast, etc.
    // could be implemented similarly based on specific requirements.

    public static void main(String[] args) {
        // Example usage of the Stack class
        Stack stack = new Stack(5);
        stack.push(10);
        stack.push(20);
        stack.push(30);
        stack.push(40);

        System.out.println("Peek: " + stack.peek());
        System.out.println("Total: " + stack.total());
        System.out.println("Average: " + stack.average());
        System.out.println("Search for 20: " + stack.search(20));
        System.out.println("Search for 50: " + stack.search(50));

        stack.displayAllElements();
        stack.displayElement();

        System.out.println("Pop: " + stack.pop());
        stack.displayAllElements();
    }
}
