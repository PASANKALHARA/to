
class Node {
    int data;
    Node next;

    public Node(int data) {
        this.data = data;
        this.next = null;
    }
}

class LinkedList {
    Node head;

    void printLinkedList() {
        Node current = head;

        while (current != null) {
            System.out.print(current.data + " ");
            current = current.next;
        }

        System.out.println();
    }

    void add(int e) {
        Node newNode = new Node(e);
        if (head == null) {
            head = newNode;
        } else {
            Node current = head;
            while (current.next != null) {
                current = current.next;
            }
            current.next = newNode;
        }
    }

    void addFirst(int e) {
        Node newNode = new Node(e);
        newNode.next = head;
        head = newNode;
    }

    void add(int index, int element) {
        if (index == 0) {
            addFirst(element);
        } else {
            Node temp = new Node(element);
            int count = 0;
            Node curr = head;
            while (count < index - 1) {
                curr = curr.next;
                count++;
            }
            temp.next = curr.next;
            curr.next = temp;
        }
    }

    boolean isEmpty() {
        return (head == null);
    }

    Node deleteFirst() {
        if (isEmpty()) {
            System.out.println("Linked list is empty. Cannot delete.");
            return null;
        }

        Node temp = head;
        head = head.next;
        temp.next = null;
        return temp;
    }

    Node find(int key) {
        Node current = head;
        while (current != null && current.data != key) {
            current = current.next;
        }
        return current;
    }

    void delete(int key) {
        if (isEmpty()) {
            System.out.println("Linked list is empty. Cannot delete.");
            return;
        }

        Node current = head;
        Node previous = null;

        while (current != null && current.data != key) {
            previous = current;
            current = current.next;
        }

        if (current == null) {
            System.out.println("Key not found in the linked list.");
            return;
        }

        if (previous == null) {
            head = current.next;
        } else {
            previous.next = current.next;
        }

        current.next = null;
    }
}

public class LinkedListApplication {
    public static void main(String[] args) {
        LinkedList linkedList = new LinkedList();

        System.out.println("Is the linked list empty ? " + linkedList.isEmpty());

        linkedList.add(1);
        linkedList.add(2);
        linkedList.add(3);
        linkedList.add(4);

        linkedList.addFirst(5);
        linkedList.add(2, 6);

        System.out.print("Linked list after insertion : ");
        linkedList.printLinkedList();

        Node deletedNode = linkedList.deleteFirst();
        System.out.println("Deleted node : " + deletedNode.data);

        System.out.print("Linked list after deletion : ");
        linkedList.printLinkedList();

        int keyToFind = 2;
        Node foundNode = linkedList.find(keyToFind);
        if (foundNode != null) {
            System.out.println("Node with key " + keyToFind + " found.");
        } else {
            System.out.println("Node with key " + keyToFind + " not found.");
        }

        int keyToDelete = 3;
        linkedList.delete(keyToDelete);
        System.out.print("Linked list after deleting node with key " + keyToDelete + " : ");
        linkedList.printLinkedList();
    }
}
