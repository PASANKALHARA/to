import java.util.Scanner;

class Queue{
	int maxSize;
	int[] queueArray;
	int front;
	int rear;
	int size;
	
	public Queue(int s){
		front=-1;
		rear=-1;
		maxSize=s;
		queueArray=new int[maxSize];
		size=0;
	}
	public boolean isFull(){
		return rear==maxSize-1;
	}
	public boolean isEmpty(){
		if(front<0 || front>rear){
			return true;
		}
		else{
			return false;
		}
	}
	public void enQueue(int x){
		if(isFull()){
			System.out.println("Queue is Full");
		}
		else{
			if(isEmpty()){
				front=rear=0;
			}
			else{
				rear=rear+1;
			}
			queueArray[rear]=x;
			size++;
            System.out.println("Enqueued : "+x); 
		}
	}
	public int deQueue(){
		int removeItem=0;
		if(isEmpty()){
			System.out.println("Queue is Empty");
		}
		else if(front==rear){
			removeItem=queueArray[front];
			front=rear=-1;
		}
		else{
			removeItem=queueArray[front];
			front=front+1;
		}
		size--;
        System.out.println("Dequeued : "+ removeItem);
		return removeItem;
        
	}
	public void display(){
		if(isEmpty()){
			System.out.println("My queue is Empty");
		}
		else{
            System.out.println("Current Items : ");
			for(int i=front;i<rear+1;i++){
				System.out.println(queueArray[i]+"\t");
			}
		}
	}
	public void reverseQueue(){
		System.out.println("The reverse queue is : ");
		for(int i=rear;i>=front;i--){
			System.out.print(queueArray[i]+"\t");
		}
	}
	public int peek(){
        System.out.println("Peeked : "+queueArray[front]);
		return queueArray[front];
	}
	public static void main(String[] args){
		Queue q1 = new Queue(8);
		q1.enQueue(10);
		q1.enQueue(33);
		q1.enQueue(28);
		q1.enQueue(43);
		q1.peek();
        q1.enQueue(11);
        q1.enQueue(27);
        q1.peek();
		q1.deQueue();
		q1.display();
        q1.enQueue(18);
        q1.display();

	}
}