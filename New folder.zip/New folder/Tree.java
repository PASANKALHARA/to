
class Node{
    int data;
	Node left;
	Node right;
    int key;
	
	public Node(int data){
		this.data = data;
		this.right = this.left = null;
	}
}
public class EX01 {
    Node root;

    public void add(int value){
		root = addRecursive(root,value);
	}
	private Node addRecursive(Node current,int value){
		if(current == null){
            return new Node(value);
        }
        if(value < current.data){
			current.left = addRecursive(current.left,value);
		}
		if(value > current.data){
			current.right = addRecursive(current.right,value);
		}
		else{
			return current;
		}
		return current;
	}
    public void tarverseInOrder(){
        traverseInOrderRecursive(root);
    }
    public void traverseInOrderRecursive(Node node){
        if(node != null){
            traverseInOrderRecursive(node.left);
            System.out.print(" "+node.data);
            traverseInOrderRecursive(node.right);
        }
    }
    public void traversePreOrder(){
        traversePreOrderRecursive(root);
    }
    public void traversePreOrderRecursive(Node node){
        if(node != null){
            System.out.print(" "+node.data);
            traversePreOrderRecursive(node.left);
            traversePreOrderRecursive(node.right);
        }
    }
    public void traversePostOrder(){
        traversePostOrderRecursive(root);
    }
    public void traversePostOrderRecursive(Node node){
        if(node != null){
            traversePostOrderRecursive(node.left);
            traversePostOrderRecursive(node.right);
            System.out.print(" "+node.data);
        }
    }
    // Method to find a node with a specified key value
    public Node findNode(int key) {
        return findNodeRec(root, key);
    }

    private Node findNodeRec(Node root, int key) {
        // If the root is null or the key matches the root's key, return the root
        if (root == null || root.key == key) {
            return root;
        }
        // If the key is less than the root's key, search in the left subtree
        if (key < root.key) {
            return findNodeRec(root.left, key);
        }
        // If the key is greater than the root's key, search in the right subtree
        return findNodeRec(root.right, key);
    }
    public static void main(String[] args) {
        EX01 obj = new EX01();

        obj.add(75);
        obj.add(63);
        obj.add(89);
        obj.add(59);
        obj.add(61);
        obj.add(86);
        obj.add(76);
        obj.add(70);
        obj.add(96);

         // Search for node 7
         Node foundNode = obj.findNode(75);
         if (foundNode != null) {
             System.out.println("Node 7 found in the tree.");
         } else {
             System.out.println("Node 7 not found in the tree.");
         }

        System.out.print("In order traversing : ");
        obj.tarverseInOrder();
        System.out.println();

        System.out.print("Post Order traversing : ");
        obj.traversePostOrder();
        System.out.println();

        System.out.print("Pre Order traversing : ");
        obj.traversePreOrder();
        System.out.println();
        
    }
}
