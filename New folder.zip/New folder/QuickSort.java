

import java.util.Arrays;

public class QuickSort {

	static void quickSort(int array[], int low, int high) {
		if(low < high) {
			int pivot = partition(array, low, high);
			
			quickSort(array, low, pivot-1);
			
			quickSort(array, pivot + 1, high);
		}
	}
	
	static int partition(int array[], int low, int high) { // 13,2,6,15,43,23,78
		int pivot = array[high];
		
		int i = (low - 1);
		// j == 6
		//high == 6
		for(int j=low; j < high; j++) {
			if(array[j] <= pivot) { // 06 < 15
				
				i++; // 2
				int temp = array[i]; // 23
				array[i] = array[j]; // 6
				array[j] = temp; // 23
			}
		}
		
		int temp = array[i + 1]; // 78
		array[i+1] = array[high]; //15
		array[high] = temp; // 78
		
		return (i+1);
		
	}
	
	public static void main(String[] args) {
		int[] data = {13,23,2,78,43,6,15};
		//size = 7
		// index = 6 ---> 0 1 2 3 4 5 6 
		
		System.out.println("Array before sorting : ");
		System.out.println(Arrays.toString(data));
		int size = data.length;
		
		quickSort(data, 0, size - 1);
		
		System.out.println("Array after sorting : ");
		System.out.println(Arrays.toString(data));
	}

}
